use HumanStorageDevice;
SELECT * FROM Celler WHERE FangeNR = 1743;

SELECT * FROM BEVEGELSER WHERE RomNR = 1;

SELECT * FROM Fanger WHERE SikkerhetsNivå=1;

SELECT * FROM Bevegelser WHERE FangeNR = 1234;