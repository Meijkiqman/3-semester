// ADS101 Algoritmer og Datastrukturer for spill 2020
// Dag Nylund, Høgskolen i Innlandet

#include <iostream>
#include "quadtre.h"
using namespace std;

int main()
{
    // Container med statiske objekter her, vi kune ha valgt pekere
    vector<GameObject> gameObjects;

    // Lager område på figur abcd er hjørnene i rekkefølge mot urviseren
    Vector2d a{-4, -3};
    Vector2d b{ 4, -3};
    Vector2d c{ 4,  3};
    Vector2d d{ -4, 3};

    // Legger inn objektene i gameObjects
    // nv
    Vector2d p{-3.25, 0.25}; gameObjects.push_back(GameObject{p, "grantre1"});
    p.x = -3.25; p.y = 1.5; gameObjects.push_back(GameObject{p, "grantre2"});
    p.x = -1.5; p.y = 1.0; gameObjects.push_back(GameObject{p, "grantre3"});
    // sv - nv
    p.x = -3.25; p.y = -0.75; gameObjects.push_back(GameObject{p, "stjerne1"});
    p.x = -2.75; p.y = -1.0; gameObjects.push_back(GameObject{p, "mynt1"});
    // sv - no
    p.x = -1.5; p.y = -0.5; gameObjects.push_back(GameObject{p, "stjerne2"});
    p.x = -0.5; p.y = -0.5; gameObjects.push_back(GameObject{p, "mynt2"});
    p.x = -1.5; p.y = -1.0; gameObjects.push_back(GameObject{p, "seddel1"});
    // sv - so
    p.x = -1.75; p.y = -2.0; gameObjects.push_back(GameObject{p, "seddel2"});
    // so
    p.x = 2.75; p.y = -1.0; gameObjects.push_back(GameObject{p, "grantre4"});
    p.x = 2.0; p.y = -2.0; gameObjects.push_back(GameObject{p, "vann"});
    // no - sv
    p.x = 0.5; p.y = 0.5; gameObjects.push_back(GameObject{p, "fiende"});
    // no - so
    p.x = 3.0; p.y = 0.25; gameObjects.push_back(GameObject{p, "spiller"});

    // Lager quadtre med subdivisjon som på figuren
    QuadTre root{a, b, c, d};
    root.subDivide(1);
    QuadTre* subtre = root.find(Vector2d{-1,-1});
    subtre->subDivide(1);
    subtre = root.find(Vector2d{1,1});
    subtre->subDivide(1);

    // Nå skal vi lage struktur. Vi setter inn alle
    // objektene, og samler dem i quads. Når vi ikke
    // bruker pekere eller referanser, får vi kopier
    // Vi bør gjøre om dette senere

    cout << "-------------------------" << endl;
    cout << "Setter inn og skriver ut " << endl;
    cout << "-------------------------" << endl;

    for (auto go : gameObjects) // for alle gameObjektene
    {
        auto p = root.insert(go);
        p->print();
    }

    cout << "---------------------" << endl;
    cout << "Skriver ut objektene " << endl;
    cout << "---------------------" << endl;

    subtre = root.find(Vector2d{-1, 1});
    subtre->print();
    subtre = root.find(Vector2d{-2.5, -1});
    subtre->print();
    subtre = root.find(Vector2d{-1.5, -2});
    subtre->print();
    subtre = root.find(Vector2d{-1.5, -1});
    subtre->print();
    subtre = root.find(Vector2d{ 1, -1});
    subtre->print();
    subtre = root.find(Vector2d{ 1, 1});
    subtre->print();
    subtre = root.find(Vector2d{ 3, 1});
    subtre->print();
    return 0;
}
